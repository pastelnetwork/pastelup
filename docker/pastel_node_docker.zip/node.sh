#!/bin/bash
./pastel-utility install node
./pastel-utility start node


