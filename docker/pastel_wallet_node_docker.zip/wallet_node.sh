#!/bin/bash
./pastel-utility install walletnode
ls /root/.pastel/
./pastel-utility start walletnode
ps -aux
